var PHP_ZTS ="no"
var PHP_DLL_LIB ="php5.lib"
var PHP_DLL ="php5.dll"

